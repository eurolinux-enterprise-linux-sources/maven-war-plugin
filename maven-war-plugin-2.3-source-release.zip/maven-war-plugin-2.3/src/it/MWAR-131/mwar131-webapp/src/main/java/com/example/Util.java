package com.example;

public class Util
{
    public static boolean isPresent()
    {
        return true;
    }
}
