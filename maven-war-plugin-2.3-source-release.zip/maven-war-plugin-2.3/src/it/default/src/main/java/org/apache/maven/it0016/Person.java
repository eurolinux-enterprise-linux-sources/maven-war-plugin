package org.apache.maven.it0016;

public class Person
{
    private String name;
    
    public void setName( String name )
    {
        this.name = name;
    }
    
    public String getName()
    {
        return name;
    }
}
